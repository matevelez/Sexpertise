<?php
session_start();
include_once "../conexion.php";

$email = $_POST["email"];
$nombre_usuario = $_POST["nombre_usuario"];
$pwd = $_POST["password"];

//para inicio de sesion====== SELECT * FROM usuario WHERE email = as && contraseña = "asdkalwj"

// INSERT INTO usuario(email, nombre, password) VALUE("email", "nombre", "password")
$sql = "INSERT INTO usuario(email, nombre_usuario, password) VALUES(\"$email\", \"$nombre_usuario\", \"$pwd\")";
$user = $con->query($sql); // ejecutamos la consulta
header("Location: http://localhost/SexPertise/Vista/registrarse/registro.php?") // volvemos a la página de registro
?>