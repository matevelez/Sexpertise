<?php
include_once "../conexion.php";

$email = $_POST["email"];
$password = $_POST["password"];

//para inicio de sesion====== SELECT * FROM usuario WHERE email = as && contraseña = "asdkalwj"

// SELECT * FROM usuarios WHERE email = $email && password = $password
$sql = "SELECT * FROM usuario WHERE email = \"$email\" && password = \"$password\"";
$user = $con->query($sql); // ejecuta la consulta

if(mysqli_num_rows($user) > 0 ){

    while($row = $user->fetch_assoc()){ // obtiene los datos de la consulta con la función fetch_assoc y le asigna los resultados a la variable $row
        session_start(); // iniciamos una sesión para guardar variables globales
    
        $_SESSION["usuario"] = $row; // guardamos una variable global
    }
    header("Location: http://localhost/SexPertise/vista/html/index.php"); // volvemos a la página de registro
} else {
    echo "<script> alert('Verifica los datos ingresados, los que ingresaste no existen.') </script>";

}

?>