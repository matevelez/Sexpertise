<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SexPertise</title>
    <link rel="icon" href="../multimedia/E (1).png">
    <link rel="stylesheet" href="../css/estilos.css">
    <link rel="stylesheet" href="../multimedia/fontawesome/css/all.min.css">
</head>
<body>
    
    
    <header>
        <nav>
            <a href="#contenedor sobre-nosotros"><img src="../multimedia/E (1).png" alt="Logo" class="Logo"></a>
            <a href="#contenedor sobre-nosotros">Inicio</a>
            <a href="#portafolio">Portafolio</a>
            <a href="#">Actividades</a>
            <a href="contacto.html">Contacto</a>

        </nav>
        <nav class="inicio">
            <?php
            session_start();
            if(isset($_SESSION["usuario"])){
                echo "<a href=\"../../controlador/cerrar/cerrar_sesion.php\"><i class=\"fa-solid fa-arrow-right-from-bracket\"></i> CERRAR SESIÓN</a>";

            } else {
                echo "
                <a href=\"../registrarse/registro.php\"><i class=\"fa fa-user\"></i> INICIAR SESIÓN</a>
                <a href=\"../registrarse/registro.php\">REGISTRARSE</a>
                ";
            }
            ?>

        </nav>
        <section class="textos-header">
            <h1>SexPertise</h1>
            <h2>Con responsabilidad todo es mas cool</h2>

        </section>
    

      <div class="wave" style="height: 150px; overflow: hidden;" ><svg viewBox="0 0 500 150" preserveAspectRatio="none" style="height: 100%; width: 100%;"><path d="M0.00,49.98 C158.29,178.13 348.47,-17.25 500.00,49.98 L500.00,150.00 L0.00,150.00 Z" style="stroke: none; fill:#ffff;"></path></svg></div>
    </header>
    <main>
        <section class="contenedor sobre-nosotros" id="contenedor sobre-nosotros">
            <h2 class="titulo">¡¡Bienvenidos!!</h2>
           <div class="contenedor-sobre-nosotros">
            <img src="https://cdn.domestika.org/c_limit,dpr_auto,f_auto,q_auto,w_820/v1461808984/content-items/001/607/116/sexual_-_design_-_9-original.jpg?1461808984" alt="" class="imagen-about-us">
            <div class="contenido-textos">
                <h3><span>1</span>¿Que encontraras?</h3>
                <p> Podras encontrar muchas fuentes de informacion, crucigramas, videos educativos y mas actividades dinamicas que serviran como formas de aprendizaje. ¡Esperamos resuelvas tus dudas y disfrutes de todo el contenido super interesante e importante!.</p>
                <h3><span>2</span>¿Por que es importante?</h3>
                <p>Esta pagina va dirigida a todas las personas que tengan alguna duda o curiosidad sobre algo relacionado con la educacion sexual, mas especificamente temas como ITS,ETS, metodos anticonceptivos y diversidad sexual. Todo esto porque sabemos que es una necesidad estar informado de todo esto, porque interviene directamente en la vida de tod@s, es algo que se debe tomar con responsabilidad, respeto y conciencia.</p>
            </div>
           </div>
        </section>
        <section class="portafolio" id="portafolio">
            <div class="contenedor">
                <h2 class="titulo">Portafolio</h2>
                <div class="galeria-port">

                    <div class="imagen-port">
                        <img src="https://www.plenainclusion.org/wp-content/uploads/2022/06/ilustracion-sexualidad.jpg" alt="">
                        <div class="hover-galeria">
                            <a href="sexualidad.html">Sexualidad</a>

                        </div>
                   
                    </div>

                    <div class="imagen-port">
                        <img src="https://img.freepik.com/vector-gratis/conjunto-diferentes-metodos-anticonceptivos_23-2148662287.jpg?w=2000" alt="">
                        <div class="hover-galeria">
                            <a href="metodos.html">Metodos Anticonceptivos</a>
                        </div>
                    </div>

                    <div class="imagen-port">
                        <img src="https://media.istockphoto.com/id/509037182/es/vector/virus-icono.jpg?s=612x612&w=0&k=20&c=Fnatk-ZXNYrJzjxg9uIHzVP89TYxqm_IkD_7ZO76O_M=" alt="">
                        <div class="hover-galeria">
                            <a href="ETS.html">ETS y ITS</a>
                        </div>
                    </div>

                    <div class="imagen-port">
                        <img src="https://www.plenainclusion.org/wp-content/uploads/2022/06/diversidad-sexual.jpg" alt="">
                        <div class="hover-galeria">
                            <a href="diversidad.html">Diversidad Sexual</a>
                        </div>
                    </div>

                    <div class="imagen-port">
                        <img src="https://us.123rf.com/450wm/nicoletaionescu/nicoletaionescu2006/nicoletaionescu200600089/150350983-adolescente-ni%C3%B1a-experimentar-pubertad-tenencia-un-sost%C3%A9n.jpg?ver=6" alt="">
                        <div class="hover-galeria">
                            <a href="pubertad.html">La Pubertad</a>
                        </div>
                    </div>
                    
                    <div class="imagen-port">
                        <img src="https://img.freepik.com/vector-premium/hombre-mujer-maniqui-cuerpo-humano-ilustracion-personaje_37112-53.jpg" alt="">
                        <div class="hover-galeria">
                            <a href="tucuerpo.html">Tu Cuerpo</a>
                        </div>
                    </div>
                



                </div>
            </div>
        </section>
        <section class="clientes contenedor" id="clientes contenedor">
            <h2 class="titulo">Haznos saber tu opinión</h2>
            <div class="cards">
                <div class="card">
                    <img src="https://img.freepik.com/vector-premium/companeros-clase-que-van-escuela-ilustracion-vectorial-plana-par-alumnos-uniforme-tomados-mano-aislados-personajes-dibujos-animados_71593-498.jpg" alt="">
                    <div class="contenido-texto-card">
                        <a href="comentarios.html"><h4> Click aqui</h4></a>
                        <p> Para dudas, inquietudes, recomendaciones o comentarios</p>
                    </div>
                </div>

            </div>
        </section>
    </main>
    <footer>
        <div class="contenedor-footer">
            <div class="content-foo">
                <h4>Ubicacion</h4>
                <p>Institución Educativa Diego Echavarria Misas</p>
                 </div>

                <div class="contenedor-footer">
                    <div class="content-foo">
                    <h4>Celular</h4>
                    <p>715364376</p>
                </div>
        </div>
            <h2 class="titulo-final">&copy; SexPertise | Mateo V, Mateo C , Miguel, Valentina</h2>
    </footer>
</body>
</html>