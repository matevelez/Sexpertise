<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>  
<title>Registro</title>
</head>
<body>
  <div class="container-form register">
    <div class="information">
      <div class="info-childs">
        <h2>Bienvenido</h2>
        <p>Para unirte a esta comunidad educativa inicia sesión</p>
        <input type="button" value="Iniciar sesión" id="sign-in">
      </div>
    </div>
    <div class="form-information">
      <div class="form-information-childs">
        <h2>Crear una cuenta</h2>
        <p>
        </p>
        <div class="icons">
        <i class='bx bxl-google'></i>
       <i class='bx bxl-facebook'></i>
       <i class='bx bxl-instagram'></i>
        </div>
        <p>O usa tu email para registrarte</p>
        <form action="../../controlador/registrar/rusuarios.php" method="POST" class="form">
          <label>
          <i class='bx bx-user-circle'></i>
            <input type="text" placeholder="Nombre de usuario" name="nombre_usuario" required>
          </label>
          <label>
          <i class='bx bx-envelope'></i>
          <input type="email" placeholder="Correo Electronico" name="email" required>
          </label>
          <label>
          <i class='bx bx-lock-alt' ></i>
          <input type="password" placeholder="Contraseña" name="password" required>
          </label>

          <input type="submit" value="Registrarse" href="">

        </form>
      </div>
    </div>
  </div>






 <div class="container-form login hide">
    <div class="information">
      <div class="info-childs">
        <h2>¡Bienvenido Nuevamente!</h2>
        <p>Si eres nuevo en esta comunidad educativa regístrate</p>
        <input type="button" value="Registrarse" id="sign-up">
      </div>
    </div>
    <div class="form-information">
      <div class="form-information-childs">
        <h2>Inicia Sesión</h2>
        <div class="icons">
        <i class='bx bxl-google'></i>
       <i class='bx bxl-facebook'></i>
       <i class='bx bxl-instagram'></i>
        </div>
        <p>O iniciar sesión con una cuenta</p>
        <form action="../../controlador/ingresar/validar.php" method="POST" class="form">
          <label>
          <i class='bx bx-envelope'></i>
          <input type="email" placeholder="Correo Electronico" name="email" required>
          </label>
          <label>
          <i class='bx bx-lock-alt' ></i>
          <input type="password" placeholder="Contraseña" name="password" required>
          </label>
          <input type="submit" value="Iniciar Sesión">

        </form>
      </div>
    </div>
  </div>
  <script src="inicio.js"></script>
  
</body>
</html>