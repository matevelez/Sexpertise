<?php
/*
session_start();
error_reporting(0);
$varsesion = $_SESSION['usuario'];
if ($varsesion==null || $varsesion='') {
    echo"<script>alert('Usted no tiene autorizacion');window.location='../vista/ingreso.php';</script>"; 
die();//TERMINA LA SESIONES
}*/
$host="localhost";
$user="root";
$password="";
$db="sexpertise";
$con = new mysqli($host,$user,$password,$db);
//linea de codigo para verificar la conexion a la base de datos
if ($con->connect_error) {
    die("Conexion fallo: ".$con->connect_error);
}
   echo"Conexion Exitosa";

?>