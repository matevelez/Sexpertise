<?php
session_start();
include_once "../conexion.php";

$email = $_POST["email"];
$nombre_usuario = $_POST["nombre_usuario"];
$password = $_POST["password"];

//para inicio de sesion====== SELECT * FROM usuario WHERE email = as && contraseña = "asdkalwj"
$sql = "SELECT * FROM usuario WHERE email = \"$email\"";
$user = $con->query($sql); // ejecuta la consulta
if(mysqli_num_rows($user) > 0){
    echo "<script> alert('Ya existe una cuenta con ese correo, intenta iniciar sesion o con otro correo para registrarse.') </script>";
} else {
    // INSERT INTO usuario(email, nombre, password) VALUE("email", "nombre", "password")
    $sql = "INSERT INTO usuario(email, nombre_usuario, password) VALUES(\"$email\", \"$nombre_usuario\", \"$password\")";
    $user = $con->query($sql); // ejecutamos la consulta
    header("Location: http://localhost/SexPertise/vista/html/index.php"); // volvemos a la página de registro
}
?>